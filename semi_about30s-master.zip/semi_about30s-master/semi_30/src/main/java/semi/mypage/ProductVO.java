package semi.mypage;

import java.sql.Blob;

public class ProductVO {

	private int productNo;
	private String productTitle;
	private String productText;
	private int productPrice;
	private String productCategory;
	private String productComment;
	private String productFile;
	private String accountId;
	
	public ProductVO() {
		
	}
	
	public ProductVO(int productNo, String productTitle, String productText, int productPrice, String productCategory, String productComment, String productFile, String accountId) {
		this.productNo = productNo;
		this.productTitle = productTitle;
		this.productText = productText;
		this.productPrice = productPrice;
		this.productCategory = productCategory;
		this.productComment = productComment;
		this.productFile = productFile;
		this.accountId = accountId;
	}

	public int getProductNo() {
		return productNo;
	}

	public void setProductNo(int productNo) {
		this.productNo = productNo;
	}

	public String getProductTitle() {
		return productTitle;
	}

	public void setProductTitle(String productTitle) {
		this.productTitle = productTitle;
	}

	public String getProductText() {
		return productText;
	}

	public void setProductText(String productText) {
		this.productText = productText;
	}

	public int getProductPrice() {
		return productPrice;
	}

	public void setProductPrice(int productPrice) {
		this.productPrice = productPrice;
	}

	public String getProductCategory() {
		return productCategory;
	}

	public void setProductCategory(String productCategory) {
		this.productCategory = productCategory;
	}

	public String getProductComment() {
		return productComment;
	}

	public void setProductComment(String productComment) {
		this.productComment = productComment;
	}

	public String getProductFile() {
		return productFile;
	}

	public void setProductFile(String productFile) {
		this.productFile = productFile;
	}

	public String getAccountId() {
		return accountId;
	}

	public void setAccountId(String accountId) {
		this.accountId = accountId;
	}

}
